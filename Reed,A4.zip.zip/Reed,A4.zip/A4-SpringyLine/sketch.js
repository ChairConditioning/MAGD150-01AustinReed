//Springy line: Use R key and E key to adjust coordinates, to use the light switch use the mouse button.

var x1=0;
var x2=0;
var y1=400;
var y2=400;
var bg = 240;
var bg2 = 60;
var tmp=0;

function setup() {
	createCanvas(400, 400);
}

function mouseClicked() { //click anywhere to toggle lights
    tmp=bg;
    bg=bg2;
    bg2=tmp;
  }

function draw() {
  background(bg);
  strokeWeight(10);
 
  if (keyIsPressed) {
  	if (key == 'r') {
  		x1+=1;
        x2+=1;
  	} 
    else if ( key == 'e') {
  		y1-=1;
        y2-=1;
  	}
  }
  else{
  while (x1>0){
    x1-=1;
    x2-=1;
  }
    while (y1<400){
    y1+=1;
    y2+=1;
  }
  }
  
  line(x1, x2, y1, y2);
 }