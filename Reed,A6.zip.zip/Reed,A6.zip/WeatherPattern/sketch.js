var s = 1;
var shrink=true;
var a = 0;
var rotleft=true;

function setup() {

	createCanvas(800, 400);
}

function draw() {

	background(0,255,150);

	for (var x = 70; x < width + 140; x += 140) {
		cloud(x, 200);
      s-=.0001;
	}
}

function cloud(x, y) {

	push();

	translate(x, y);
  
      if (shrink==true){
    s-=.0001;
    if (s<.75){
      shrink=false;
      print("Weather icon is growing.");
    }
  }
  
  if (shrink==false){
    s+=.0002;
  if (s>=1){
      shrink=true;
    print("Weather icon is shrinking.");
  }
  }
  
   if (rotleft==true){
    a-=.1;
   }else{
      a+=.1;}
  
  if (a<=-20){
    rotleft=false;
  print("The rotation direction has flipped.");
  }
  if (a>=20){
    rotleft=true;
  print("The rotation direction has flipped.");
  }

	stroke(0);
  scale(s);
	strokeWeight(7);
  stroke(150,200,255);
	 
	 // Rain

   angleMode(DEGREES);
  rotate(a);

   line (-25, -10, -30, -20);
    line (-10, 0-40, -5, 10-40);
  line (25, 15-40, 30, 25-40);
  
  line (10, 0, 15, 10);
    line (-10, 10, -5, 20);
  line (5, 25, 10, 35);

	noStroke();

  //Sun
  fill(255,255,0);
  ellipse(-20, -90, 70, 70);
  fill(255,230,0);
  ellipse(-20, -90, 60, 60);
  
//Clouds
  fill(180);
  ellipse(-18, -65, 75, 40);
    ellipse(18, -65, 65, 55);
  ellipse(0, -80, 55, 55);
	fill(255);
    ellipse(-18, -65, 70, 35);
    ellipse(18, -65, 60, 50);
  ellipse(0, -80, 50, 50);

	fill(0);

	pop();

}