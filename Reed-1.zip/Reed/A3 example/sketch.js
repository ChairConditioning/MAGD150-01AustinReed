function setup() {
  createCanvas(400, 400);
  background(50);
}

function draw() {

  colorMode(RGB, 180);
  
  let fr = sqrt(125);
	frameRate(fr);
	print(fr);
  
  let mx = mouseX;
  let my = mouseY;
    let px = pmouseX;
	let py = pmouseY;
  let xo = px;
  let xt = py;
  let yo = mx;
  let yt = my;
  var w = abs(dist(mx, my, px, py));
  stroke(mx,my,mx-my);
  strokeWeight(w);
    line(xo, xt, yo, yt);
  
  
}